A pasta de "unit" foi criada para armazernar:

- o arquivo calculo.test.js (teste unitário referente ao caso de uso caso CT-001 - Estimar tempo e material com agulha 3.0mm e ponto baixo);

O comando no terminal para rodar APENAS o teste dessa pasta é: npm run test:unit