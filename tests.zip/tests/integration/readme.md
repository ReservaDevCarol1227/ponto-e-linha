A pasta de "integration" foi criada para armazernar:

- o arquivo api.test.js (teste de integração referente ao caso de uso CT-002 - Testar login com credenciais válidas.);

O comando no terminal para rodar APENAS o teste dessa pasta é: npm run test:integration